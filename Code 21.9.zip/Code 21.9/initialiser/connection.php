<?php

$host="localhost";
$user="root";
$pass="password";
$db="Beyond_Screens";

?>