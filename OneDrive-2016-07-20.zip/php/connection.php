<?php

$host="localhost";
$user="root";
$pass="";
$db="Beyond_Screens";

?>